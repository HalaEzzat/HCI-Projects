﻿namespace CompareImages_Difference
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CurrentFrame = new System.Windows.Forms.PictureBox();
            this.resultbox = new System.Windows.Forms.PictureBox();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.PreviousFrame = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.Contour_lbl = new System.Windows.Forms.Label();
            this.ContourThresh_Value = new System.Windows.Forms.TrackBar();
            this.Theshold_LBL = new System.Windows.Forms.Label();
            this.Threshold_Value = new System.Windows.Forms.TrackBar();
            this.label3 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.CurrentFrame)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultbox)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PreviousFrame)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ContourThresh_Value)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Threshold_Value)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // CurrentFrame
            // 
            this.CurrentFrame.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.CurrentFrame.Location = new System.Drawing.Point(3, 19);
            this.CurrentFrame.Name = "CurrentFrame";
            this.CurrentFrame.Size = new System.Drawing.Size(653, 317);
            this.CurrentFrame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.CurrentFrame.TabIndex = 0;
            this.CurrentFrame.TabStop = false;
            // 
            // resultbox
            // 
            this.resultbox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.resultbox.Location = new System.Drawing.Point(3, 19);
            this.resultbox.Name = "resultbox";
            this.resultbox.Size = new System.Drawing.Size(653, 317);
            this.resultbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.resultbox.TabIndex = 1;
            this.resultbox.TabStop = false;
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Controls.Add(this.panel4, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel3, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.panel2, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.panel1, 0, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 12);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 2;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(1324, 685);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.AutoScroll = true;
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.PreviousFrame);
            this.panel4.Location = new System.Drawing.Point(3, 345);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(656, 337);
            this.panel4.TabIndex = 6;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(3, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(117, 16);
            this.label4.TabIndex = 3;
            this.label4.Text = "Previous Frame";
            // 
            // PreviousFrame
            // 
            this.PreviousFrame.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PreviousFrame.Location = new System.Drawing.Point(3, 19);
            this.PreviousFrame.Name = "PreviousFrame";
            this.PreviousFrame.Size = new System.Drawing.Size(653, 318);
            this.PreviousFrame.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PreviousFrame.TabIndex = 1;
            this.PreviousFrame.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.AutoScroll = true;
            this.panel3.Controls.Add(this.Contour_lbl);
            this.panel3.Controls.Add(this.ContourThresh_Value);
            this.panel3.Controls.Add(this.Theshold_LBL);
            this.panel3.Controls.Add(this.Threshold_Value);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Location = new System.Drawing.Point(665, 345);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(656, 337);
            this.panel3.TabIndex = 5;
            // 
            // Contour_lbl
            // 
            this.Contour_lbl.AutoSize = true;
            this.Contour_lbl.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Contour_lbl.Location = new System.Drawing.Point(455, 118);
            this.Contour_lbl.Name = "Contour_lbl";
            this.Contour_lbl.Size = new System.Drawing.Size(167, 16);
            this.Contour_lbl.TabIndex = 7;
            this.Contour_lbl.Text = "Contour Threshold: 100";
            // 
            // ContourThresh_Value
            // 
            this.ContourThresh_Value.Location = new System.Drawing.Point(49, 118);
            this.ContourThresh_Value.Maximum = 10000;
            this.ContourThresh_Value.Name = "ContourThresh_Value";
            this.ContourThresh_Value.Size = new System.Drawing.Size(409, 45);
            this.ContourThresh_Value.TabIndex = 6;
            this.ContourThresh_Value.TickFrequency = 100;
            this.ContourThresh_Value.Value = 100;
            this.ContourThresh_Value.Scroll += new System.EventHandler(this.Contour_Value_Scroll);
            // 
            // Theshold_LBL
            // 
            this.Theshold_LBL.AutoSize = true;
            this.Theshold_LBL.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Theshold_LBL.Location = new System.Drawing.Point(455, 67);
            this.Theshold_LBL.Name = "Theshold_LBL";
            this.Theshold_LBL.Size = new System.Drawing.Size(177, 16);
            this.Theshold_LBL.TabIndex = 5;
            this.Theshold_LBL.Text = "Movement Threshold: 60";
            // 
            // Threshold_Value
            // 
            this.Threshold_Value.Location = new System.Drawing.Point(49, 67);
            this.Threshold_Value.Maximum = 254;
            this.Threshold_Value.Name = "Threshold_Value";
            this.Threshold_Value.Size = new System.Drawing.Size(409, 45);
            this.Threshold_Value.TabIndex = 4;
            this.Threshold_Value.TickFrequency = 20;
            this.Threshold_Value.Value = 60;
            this.Threshold_Value.Scroll += new System.EventHandler(this.Threshold_Value_Scroll);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(3, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 16);
            this.label3.TabIndex = 3;
            this.label3.Text = "Settings";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.AutoScroll = true;
            this.panel2.Controls.Add(this.label2);
            this.panel2.Controls.Add(this.resultbox);
            this.panel2.Location = new System.Drawing.Point(665, 3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(656, 336);
            this.panel2.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(3, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(192, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "Absolute Frame Difference";
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.AutoScroll = true;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.CurrentFrame);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(656, 336);
            this.panel1.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Camera Output";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1348, 709);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.CurrentFrame)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.resultbox)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PreviousFrame)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ContourThresh_Value)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Threshold_Value)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox CurrentFrame;
        private System.Windows.Forms.PictureBox resultbox;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.PictureBox PreviousFrame;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label Contour_lbl;
        private System.Windows.Forms.TrackBar ContourThresh_Value;
        private System.Windows.Forms.Label Theshold_LBL;
        private System.Windows.Forms.TrackBar Threshold_Value;
    }
}

